package struct;

import struct.Variable;

public class Parameter extends Variable {

	public Parameter(String name, String type) {
		super(name, type);
	}

}
